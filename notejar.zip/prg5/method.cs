<%@ Import Namespace="System.Xml.Xsl" %>
<%@ Import Namespace="System.Xml.xPath" %>
<script language="C#" runat="server">
public void Page_Load(Object sender,EventArgs E){
string xmlpath=Server.MapPath("listing7.1.xml");
string xslpath=Server.MapPath("listing7.2.xsl");
XPathDocument doc=new XPathDocument(xmlPath);
XslTransform transform=new XslTransform();
transform.Load(xslPath);
XmlTextWriter writer=new XmlTextWriter(Response.Output);
writer.Formatting = Formatting.Indented;
writer.Indentation=4;
transform.Transform(doc,null,writer);
}
</script>
